Name: Allen Chen
NetID: AC408

Server Address: https://allenchendemo.herokuapp.com/
Working Endpoint: Should be all of them. For example, /api/courses/ (https://ac408p6.herokuapp.com/api/courses/)